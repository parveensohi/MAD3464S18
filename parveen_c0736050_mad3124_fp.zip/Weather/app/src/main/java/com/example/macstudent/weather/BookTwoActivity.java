package com.example.macstudent.weather;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class BookTwoActivity extends AppCompatActivity {
    PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_two);

        pdfView = (PDFView)findViewById(R.id.pdfView);
        pdfView.fromAsset("lookin_for_alaska.pdf").load();
    }
}

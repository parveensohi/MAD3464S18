package com.example.macstudent.weather;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class User_profile extends AppCompatActivity {
    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;
    EditText name ,email , phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile);
        SharedPreferences sharedpreferences = getSharedPreferences("mypreference",
                Context.MODE_PRIVATE);

        String user_email = (sharedpreferences.getString("email", ""));
        name = (EditText)findViewById(R.id.edt_name);
        email = (EditText)findViewById(R.id.edt_email);
        phone = (EditText)findViewById(R.id.eddt_phone);

        dbHelper = new DBHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from TouristInfo where Email='"+user_email+"'",null);
        if (cursor.moveToFirst())
        {
            do
            {
                String s1 = cursor.getString(cursor.getColumnIndex("Name"));
                String s2 = cursor.getString(cursor.getColumnIndex("Email"));
                String s3 = cursor.getString(cursor.getColumnIndex("Phone"));
                name.setText(s1);
                email.setText(s2);
                phone.setText(s3);

            }while (cursor.moveToNext());
        }
        Button btn_update = (Button)findViewById(R.id.btn_update);
        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isUpdate = dbHelper.updateData(name.getText().toString(),
                        email.getText().toString(),
                        phone.getText().toString());
                if(isUpdate == true)
                    Toast.makeText(User_profile.this,"Data Update",Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(User_profile.this,"Data not Updated",Toast.LENGTH_LONG).show();

            }
        });

    }
}

package com.example.macstudent.weather;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class ContactActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton imgcall, imgsms, imgemail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        imgcall = findViewById(R.id.imgcall);
        imgcall.setOnClickListener(this);

        imgsms = findViewById(R.id.imgsms);
        imgsms.setOnClickListener(this);

        imgemail = findViewById(R.id.imgemail);
        imgemail.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.imgcall:
                makeCall();
                break;
            case R.id.imgsms:
                sendSMS();
                break;
            case R.id.imgemail:
                sendEmail();
                break;
        }
    }

    private void makeCall(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4377755575"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(), "Call permission denied",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        startActivity(callIntent);
    }

    private  void sendSMS(){
        Intent smsintent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:4377755575"));
        smsintent.putExtra("sms_body", "This is a test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(), "SMS permission denied",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        startActivity(smsintent);

    }

    private void sendEmail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"rutvi.gajipara@gmail.com","jasmeetkaursaini.r@gmail.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Test MEssage");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "This is a test email from MAD class");

        emailIntent.setType("*/*");

        startActivity(Intent.createChooser(emailIntent, "select email profile"));
    }

}

package com.example.macstudent.weather;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class E_optionActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnbone,btnbtwo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_e_option);
        btnbone = findViewById(R.id.btnbone);
        btnbone.setOnClickListener(this);
        btnbtwo = findViewById(R.id.btnbtwo);
        btnbtwo.setOnClickListener(this);

    }
    @Override
    public void onClick(View view) {

    if(view.getId() == R.id.btnbone) {
            startActivity(new Intent(getApplicationContext(), BookOneActivity.class));
       }
    else if(view.getId() == R.id.btnbtwo)
        {
            startActivity(new Intent(getApplicationContext(), BookTwoActivity.class));
        }

    }
}

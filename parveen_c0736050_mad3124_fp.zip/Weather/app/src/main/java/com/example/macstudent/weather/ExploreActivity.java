package com.example.macstudent.weather;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.TextView;

public class ExploreActivity extends AppCompatActivity implements View.OnClickListener {
ImageButton imgCN,imgMuseum,imgAquarium,imgIsland,imgEaton;
    TextView txtCN,txtMuseum,txtAquarium,txtIsland,txtEaton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        imgCN = findViewById(R.id.imgCN);
        imgCN.setOnClickListener(this);
        imgMuseum = findViewById(R.id.imgMuseum);
        imgMuseum.setOnClickListener(this);
        imgAquarium = findViewById(R.id.imgAquarium);
        imgAquarium.setOnClickListener(this);
        imgIsland = findViewById(R.id.imgIsland);
        imgIsland.setOnClickListener(this);
        imgEaton = findViewById(R.id.imgEaton);
        imgEaton.setOnClickListener(this);
        txtAquarium = findViewById(R.id.txtAquarium);
        txtCN = findViewById(R.id.txtCN);
        txtMuseum = findViewById(R.id.txtMuseum);
        txtIsland = findViewById(R.id.txtIsland);
        txtEaton = findViewById(R.id.txtEaton);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgCN:
                Intent cnTowerIntent = new Intent(getApplicationContext(), DiscriptionActivity.class);
                cnTowerIntent.putExtra("URL", "https://en.wikipedia.org/wiki/CN_Tower");
                startActivity(cnTowerIntent);
                break;

            case R.id.imgMuseum:
                Intent museumIntent = new Intent(getApplicationContext(), DiscriptionActivity.class);
                museumIntent.putExtra("URL", "https://en.wikipedia.org/wiki/List_of_museums_in_Toronto");
                startActivity(museumIntent);
                break;

            case R.id.imgAquarium:
                Intent aqIntent = new Intent(getApplicationContext(), DiscriptionActivity.class);
                aqIntent.putExtra("URL", "https://en.wikipedia.org/wiki/Ripley%27s_Aquarium_of_Canada");
                startActivity(aqIntent);
                break;

            case R.id.imgIsland:
                Intent islandIntent = new Intent(getApplicationContext(), DiscriptionActivity.class);
                islandIntent.putExtra("URL", "https://en.wikipedia.org/wiki/Toronto_Islands");
                startActivity(islandIntent);
                break;

            case R.id.imgEaton:
                Intent eatonIntent = new Intent(getApplicationContext(), DiscriptionActivity.class);
                eatonIntent.putExtra("URL", "https://en.wikipedia.org/wiki/Toronto_Eaton_Centre");
                startActivity(eatonIntent);
                break;
        }
    }
}



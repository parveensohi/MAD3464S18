package com.example.macstudent.weather;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class BookOneActivity extends AppCompatActivity {
    PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_one);
        pdfView = (PDFView)findViewById(R.id.pdfView);
        pdfView.fromAsset("the_fault_in_our_stars.pdf").load();
    }
}

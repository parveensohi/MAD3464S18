package com.example.macstudent.weather;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edtEmail, edtPassword;
    Button btnLogin, btnRegister;

    DBHelper dbHelper;
    SQLiteDatabase TouristDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View v) {

        if (v.getId() == btnLogin.getId()) {

            if (verifyLogin()) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
             SharedPreferences sharedpreferences = getSharedPreferences("mypreference",
                        Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();

                editor.putString("email",edtEmail.getText().toString());
                editor.commit();
                Intent homeIntent = new Intent(this, HomeActivity.class);

                startActivity(homeIntent);

            } else {
                Toast.makeText(this, "Invalid Username/password", Toast.LENGTH_SHORT).show();
            }

        } else if (v.getId() == btnRegister.getId()) {
            Toast.makeText(this, "Register clicked", Toast.LENGTH_SHORT).show();


            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);

        }
    }

    private boolean verifyLogin() {

        try{
            TouristDB = dbHelper.getReadableDatabase();
            String columns[] = {"Email", "Password"};
            String userData[] = {edtEmail.getText().toString(), edtPassword.getText().toString()};

            Cursor cursor = TouristDB.query("TouristInfo", columns,
                    "Email = ? AND Password = ?",userData,null,null,null);

            if(cursor != null){
                if (cursor.getCount() > 0){
                    return true;
                }
            }

            return false;


        }catch(Exception e){
            Log.e("LoginActivity", e.getMessage());
            return false;
        }finally {
            TouristDB.close();
        }

    }

//    private boolean validate()
//    {
//        if(edtPassword.getText().toString().trim().length() <=0)
//        {
//            Toast.makeText(LoginActivity.this,"Please Enter Password", Toast.LENGTH_LONG).show();
//            return true;
//        }
//        return false;
//    }

}
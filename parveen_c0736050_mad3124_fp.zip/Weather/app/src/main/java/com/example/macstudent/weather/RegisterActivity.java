package com.example.macstudent.weather;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edtName, edtEmail, edtPassword, edtVpassword, edtPhone;
    Button btnRegister;

    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        edtName = findViewById(R.id.edtName);
        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);

        edtPhone = findViewById(R.id.edtPhone);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View v) {
        if (!isValidFirstName(edtName.getText().toString())) {
            edtName.setError("Invalid FirstName");
        }
        else if (!isValidEmail(edtEmail.getText().toString())) {
            edtEmail.setError("Invalid email id");
        }

        else if (!isValidPassword(edtPassword.getText().toString())) {
            edtPassword.setError("Invalid Password");
        } else if (!isValidNumber(edtPhone.getText().toString())) {
            edtPhone.setError("Invalid Mobile Number");
        } else {
            if (v.getId() == btnRegister.getId()){
                insertData();
                displayData();

                finish();
                startActivity(new Intent(this,LoginActivity.class));

            }
        }



    }

    private void insertData() {

        try{
            ContentValues cv = new ContentValues();
            cv.put("Name",edtName.getText().toString());

            cv.put("Email",edtEmail.getText().toString());
            cv.put("Password",edtPassword.getText().toString());
            cv.put("Phone",edtPhone.getText().toString());

            sqLiteDatabase = dbHelper.getWritableDatabase();
            sqLiteDatabase.insert("TouristInfo", null,cv);

            Log.v("RegisterActivity","User Account Created");

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            sqLiteDatabase.close();
        }
    }

    private void displayData(){
        try{
            sqLiteDatabase = dbHelper.getReadableDatabase();
            String columns[] = {"Name", "Email", "Password", "Phone"};

            Cursor cursor = sqLiteDatabase.query("TouristInfo",columns,
                    null,null,null, null, null);

            while (cursor.moveToNext()){
                String userData = cursor.getString(cursor.getColumnIndex("Name"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                //userData += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Phone"));

                Toast.makeText(this, userData,Toast.LENGTH_LONG).show();
            }

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            sqLiteDatabase.close();
        }
    }
    private boolean isValidFirstName(String name) {
        if (name != null && name.length() > 3) {
            return true;
        }
        return false;
    }

    // validating User Name
    private boolean isValidLastName(String user_name) {
        if (user_name != null && user_name.length() > 3) {
            return true;
        }
        return false;
    }

    // validating Password
    private boolean isValidPassword(String password) {
        if (password != null && password.length() >= 5) {
            return true;
        }
        return false;
    }


    // validating email id
    private boolean isValidEmail(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }


    // validating Number
    private boolean isValidNumber(String number) {
        if (number != null && number.length() == 10) {
            return true;
        }
        return false;
    }


    // validating Address
    private boolean isValidAddress(String address) {
        if (address != null && address.length() > 3) {
            return true;
        }
        return false;
    }

    // validating city name
    private boolean isValidCity(String city) {
        if (city != null && city.length() > 3) {
            return true;
        }
        return false;
    }

    // validating State name
    private boolean isValidState(String state) {
        if (state != null && state.length() > 3) {
            return true;
        }
        return false;
    }

    // validating Country name
    private boolean isValidCountry(String country) {
        if (country != null && country.length() > 3) {
            return true;
        }
        return false;
    }

    // validating postal Number
    private boolean isValidPin_code(String pin_code) {
        if (pin_code != null && pin_code.length() == 6) {
            return true;
        }
        return false;
    }

}
